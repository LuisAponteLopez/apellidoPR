Trabajo realizado: Luis E. Aponte Lopez
------------------------------------------------------------------------------------------------------------------------------------------------------
archivo:
 apellidospr.py
 mapa_tematico.pkl
 mapa_densidad.pkl
 poblacion.pkl
 tabla.pkl
--------------------------------------------------------------------------------------------------------------------------------------------------------
Resumen
apellidospr es un proyecto del grupo CienciaDatosPR del Departamento de Matemáticas de la Universidad de Puerto Rico en Humacao.
Este programa muestra los cantidades de persona con el mismo apellido en un pueblo , la proporciones de acuerdo al apellido. 
estos datos se aprecian en grafica de barra o mapa. Los mapas que verán serán de densidad , temático y de burbuja. 
Por otro lado, muestra un informe de posición, proporción y frecuencia del apellido. En la parte izquierda, se edita el apellido que se quiere buscar 
y para las grafica de barra, se edita la cantidad de barra que se muestra en pantalla. Por último, en la parte izquierda en la parte inferior, 
no enseña los apellido similares.

----------------------------------------------------------------------------------------------------------------------------------------------------------
link heroku: (no se  logro subir el archivo)


