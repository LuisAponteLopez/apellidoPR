# -*- coding: utf-8 -*-
"""
Created on Mon May 23 14:51:04 2022

@author: Aponte
"""


import os
import dash
import json
import random

from dash import dcc,html 
import dash_bootstrap_components as dbc
import pandas as pd
import numpy as np
import plotly.express as px
from shapely.geometry import Polygon, Point
from dash.dependencies import Input, Output


#####################################
# suppress_callback_exceptions = True
#####################################
app = dash.Dash(external_stylesheets=[dbc.themes.SUPERHERO])
server = app.server
############################################
# diccionario con la poblacion por municipio
############################################
poblacion = pd.read_pickle("poblacion.pkl")
############################################################
# tabla de contingencia de conteo de apellidos por municipio
############################################################
tabla = pd.read_pickle("tabla.pkl")

mapaMunicipios = pd.read_pickle('mapa_tematico.pkl')
mapaMunicipiosReverse = pd.read_pickle('mapa_densidad.pkl')
##arreglo de punto aleatorio en una figura inregular 
def random_points_within(poly,num_points):
    min_x,min_y,max_x,max_y = poly.bounds
    points  = []
    while len(points)<num_points:
        random_point = Point([random.uniform(min_x,max_x),
                               random.uniform(min_y,max_y)])
        if(random_point.within(poly)):
            points.append(random_point)
    return points

#devulve la poscion del apellido
def posicionDelApellido(apellido):
    tabla1 = tabla.sum().sort_values(ascending=False)
    tabla1 = tabla1.rename_axis('index').reset_index()
    posicionApellido = tabla1.index[tabla1['index']==apellido].tolist()
    total = tabla1.count().tolist()
    return posicionApellido , total
#
def totalesApellidos(apellido):
    tabla1 = tabla.sum().sort_values(ascending=False)
    totalApellido_Selecionado = tabla1[apellido]
    total_Apellido=tabla1.sum()
    return totalApellido_Selecionado.tolist(),total_Apellido.tolist()
#devulve los primeros 5 lugares donde mas se repite el apellido
def mayorFrecuencia(miApellido):
    conteo = {}
    for municipio in list(poblacion.keys()):
        conteo[municipio] = tabla[miApellido][municipio]
    # porciento de apellidos por municipio (normalizados por la población)
    porciento = {}
    for muni in list(poblacion.keys()):
        porciento[muni] = round(100*conteo[muni]/poblacion[muni], 2)
        
    top = sorted(porciento.items(), key=lambda x: x[1], reverse=True)[0:78]
    
    municipioSort = []
    porcientoSort = []
    for key, value in top:
        municipioSort.append(key)
        
    data = pd.DataFrame([municipioSort]).transpose().head()
    return data
#busca y devuelve apellido similares al seleccionado
def palabraSimilar(miApellido):
    apellidos = tabla.columns.tolist()
    listaApellido = []
    for value in apellidos:
        if value[:3] == miApellido[:3] and value != miApellido:
            listaApellido.append(value)
    return listaApellido 
#devulve un grafica de barra  
def graficoBarra(miApellido,cantidadMunicipio):
    conteo = {}
    
    for municipio in list(poblacion.keys()):
        conteo[municipio] = tabla[miApellido][municipio]
        
    # porciento de apellidos por municipio (normalizados por la población)
    porciento = {}

    for muni in list(poblacion.keys()):
        porciento[muni] = round(100*conteo[muni]/poblacion[muni], 2)

    top = sorted(porciento.items(), key=lambda x: x[1], reverse=True)[0:78]

    municipioSort = []
    porcientoSort = []

    for key, value in top:
        municipioSort.append(key)
        porcientoSort.append(float(value))

    data = pd.DataFrame([municipioSort, porcientoSort]).transpose()

    data.columns = ["municipio", "frecuencia"]

    fig = px.bar(data[0:cantidadMunicipio],
                 x="frecuencia",
                 y="municipio",
                 height=600,
                 color="municipio",
                 orientation="h")
    return fig
#devuelve un mapa Tematco
def mapaTematico(miApellido):
    conteo = {}
    for municipio in list(poblacion.keys()):
        conteo[municipio] = tabla[miApellido][municipio]
        
    # porciento de apellidos por municipio (normalizados por la población)
    porciento = {}

    for muni in list(poblacion.keys()):
        porciento[muni] = round(100*conteo[muni]/poblacion[muni], 2)

    top = sorted(porciento.items(), key=lambda x: x[1], reverse=True)[0:78]

    municipioSort = []
    porcientoSort = []

    for key, value in top:
        municipioSort.append(key)
        porcientoSort.append(float(value))
    
    #valores maximo y minimo de la escala
    minFrec = min(porcientoSort)
    maxFrec=max(porcientoSort)
    
    data = pd.DataFrame([municipioSort, porcientoSort]).transpose()

    data.columns = ["municipio", "frecuencia"]
    
  
    data["frecuencia"] = pd.to_numeric(data["frecuencia"])
    
    fig = px.choropleth_mapbox(data,geojson=mapaMunicipios,
                        locations = "municipio",
                        color = "frecuencia",
                        mapbox_style = "carto-positron",
                        center={"lat":18.25178,"lon":-66.264513},
                        opacity = 0.5,
                        color_continuous_scale="Reds",
                        range_color=(minFrec,maxFrec),
                        featureidkey="properties.NAME")
    fig.update_geos(fitbounds="locations",visible = False)
    return fig
#devuelve mapa de densidad
def mapaDensidad(miApellido):
    randPos = [] #arreglo que guarda el municipio , los puntos y la frecuencia
    for inx in range (78):
        poly = Polygon(mapaMunicipiosReverse["features"][inx]
                       ["geometry"]["coordinates"][0])
        #EXTRAER EL NOMBRE DEL MUNICIPO
        muniT = mapaMunicipiosReverse["features"][inx]["properties"]["NAME"]
        minConteo = min(tabla[miApellido])
        maxConteo = max(tabla[miApellido])
        conteo = 500*(tabla[miApellido][muniT]-
                  minConteo)/(maxConteo - minConteo)
        frec = 500*(conteo/poblacion[muniT])
        
        points = random_points_within(poly,conteo)
        
        for p in points:
            randPos.append([muniT,p.x,p.y,frec])
            
        data = pd.DataFrame(randPos)
    
        data.columns = ["municipio","latitude","longitude","frecuencia"]
        
        fig = px.density_mapbox(
                                lat=data.latitude,
                                lon=data.longitude,
                                z=data.frecuencia,
                                hover_name=data.municipio,
                                center = dict(lat=18.25178,lon=-66.264513),
                                zoom = 8,
                                mapbox_style = "stamen-terrain",
                                radius = 5)
    return fig
#devuelve un mapa de burbuja
def mapaBurbuja(miApellido):
    
    conteo = {}
    for municipio in list(poblacion.keys()):
        conteo[municipio] = tabla[miApellido][municipio]   
        # porciento de apellidos por municipio (normalizados por la población)
        porciento = []
    for muni in list(poblacion.keys()):
        porciento.append(round(100*conteo[muni]/poblacion[muni], 2))
    dataPorciento = pd.DataFrame(porciento,columns = ["porciento"])
    px.set_mapbox_access_token("pk.eyJ1IjoibHVpc2Fwb250ZTA0IiwiYSI6ImNrem9mazlkeTI5MmcydnBheGhmYmJvazUifQ.gcNZHEDhXNajP2AcYjahig")
    
    df = pd.read_csv('municipios_centroid.csv')
    horizontal_stack = pd.concat([df, dataPorciento], axis=1)
    
    fig = px.scatter_mapbox(horizontal_stack, lat="latitud", lon="longitud",
                            color="porciento", size="porciento",
                      color_continuous_scale=px.colors.cyclical.IceFire,
                      size_max=25, 
                      zoom=8)
    return(fig)
#devulve grafica vacia de no encontrar el apellido
def graficaVacia():
    return {
            "layout": {
                "xaxis": {
                    "visible": False
                },
                "yaxis": {
                    "visible": False
                },
                "annotations": [
                    {
                        "text": "No matching data found",
                        "xref": "paper",
                        "yref": "paper",
                        "showarrow": False,
                        "font": {
                            "size": 28
                        }
                    }
                ]
            }
        }

#Donde el usuario ingresa el apellido 
buscador = dbc.Card(
[
    dbc.Form(
            
        [
         
         dbc.Label("Entre apellido:",
                   style={'font-weight':'bold'}),
         dbc.Input(id="myInput",
                   type="text",
                   value="RIVERA",
                   debounce = True)
         ]
    ),
    
    dbc.Form(
        [
         
         html.Br(),
         html.P("No incluya acentos y puedes utilizar letras \
                mayusculas o minusculas",
                style = {'font-weight':'bold',
                         'color':'#2fa4e7'}),
         
         ]
    ),
    
    ],
                body = True,
                style = {'border-radius':5},
    )
#seleccionar el metodo de visualizacion y para grafica barra te permite seleccionar la cantidad de barra     
seleccionador  = dbc.Card(
    [
     dbc.Form([
     html.Div(id="dropdown_container",children=[
         dbc.Label("Metodo de visualizacion",style={'font-weight':'bold'}),
         dcc.Dropdown(
             id='dropdown',
             options=[
                 {'label': 'barras', 'value': 'graph1'},
                 {'label': 'mapa tematico', 'value': 'graph2'},
                 {'label': 'mapa densidad', 'value': 'graph3'},
                  {'label': 'mapa burbuja', 'value': 'graph4'},
                     ],
             value='graph1',
             clearable=False,
             searchable=False,
             ),
         ]),
         
     
     
         html.Br(),
         html.Div(id='slider_container',children=[
         
         dbc.Label("Cantidad de municipios",style={'font-weight':'bold'}),
         dcc.Slider(min=5,max=78,step=10,value = 10,id="input_slider",tooltip={"placement": "bottom", "always_visible": True}),
         html.Div(id="output_slider",style={'display':'block'}),
         ]),
         html.Br(),
         html.P("apellidospr es un proyecto del grupo \
                CienciaDatosPR del Departamento de \
                Matemáticas de la Universidad de Puerto Rico en Humacao",
                style = {'font-weight':'bold',
                         'color':'#2fa4e7'}),
        html.Br(),
      
     ]),],style = {'border-radius':5})

 #informacion resumina de los datos que aparece en la parte superior de la web
tablaInformatica=dbc.Card([
    dbc.Form([
            html.Div(id='apellidoSelecionado',style={'font-weight':'bold'}),
            html.Div(id='posicion',style={'font-weight':'bold'}),
            html.Div(id='persona',style={'font-weight':'bold'}),
            html.Div(id='frecuencia',style={'font-weight':'bold'})  
        ],style={'text-align': 'center'})
    
    ],style = {'border-radius':5,'height': '100%'}),
 #Donde se pone los apellido parecido
apellidoParecido = dbc.Card([
    dbc.Form([
        html.P("Apellidos similares"),
        html.Div(id='similar')
        ])
    ],style = {'border-radius':5})

##Aqui se acomoda kos div po coluna y fila 
app.layout = dbc.Container(
    [
     html.H1("ApellidosPR"),
     html.H3("Una aplicacion para el analisis y \
             visualizacion de los apellidos en Puerto Rico"),
    html.Br(),
    html.Hr(),
    
  
    dbc.Row(
        [
            
            dbc.Col([
                dbc.Row([buscador]),
                dbc.Row([seleccionador]),
                dbc.Row([apellidoParecido])
                ],
                md=4),
            dbc.Col([dbc.Row(tablaInformatica),dcc.Graph(id="visualizacion")],md=8),]##graficar
        ),
  
     ])
##donde recibe y devuelve que grafica quiere usar
@app.callback(
    Output('visualizacion', 'figure'),
    [Input(component_id='dropdown', component_property='value'),  
     Input(component_id='myInput', component_property='value'),
     Input(component_id='input_slider', component_property='value'),
     ]
)
def select_graph(grafica,miApellido,cantidadMunicipio):
    miApellido = miApellido.upper()
    try:
        if grafica == 'graph1':
            fig = graficoBarra(miApellido,cantidadMunicipio)
        elif grafica == 'graph2':
            fig = mapaTematico(miApellido)  
        elif grafica =='graph3':
            fig = mapaDensidad(miApellido)
        elif grafica == 'graph4':
            fig = mapaBurbuja(miApellido)
        fig.update_layout(margin=dict(l=10,r=10,b=10,t=1))
        fig.update_layout(showlegend = False)   
        
    except:
       fig =  graficaVacia()
    
    return fig 
##activar y desaactivar  la selecion de barra
@app.callback(
   Output(component_id='slider_container', component_property='style'),
   [Input(component_id='dropdown', component_property='value')])
def show_hide_element(value):
    if value == 'graph1':
        return {'display': 'block'}
    if value != 'graph1':
        return {'display': 'none'}
    
@app.callback(
   Output(component_id='apellidoSelecionado', component_property='children'),
   [Input(component_id='myInput', component_property='value')])
def actualizar_apellido(value):
    return f'Análisis del apellido {value}'

@app.callback(
    Output(component_id='posicion', component_property='children'),
    [Input(component_id='myInput', component_property='value')])
def actualizar_apellido(apellido):
    apellido = apellido.upper()
    try:
        posicion , total = posicionDelApellido(apellido)
        return  f'Ocupa la posición número {posicion[0]+1} entre {total[0]} apellidos distinto'
    except:
         return  f'No se puede calcular la posicion de este apellido'

@app.callback(
    Output(component_id='persona', component_property='children'),
    [Input(component_id='myInput', component_property='value')])
def totales_apellido(apellido):
    apellido = apellido.upper()
    try:
        totalApellidoSelecionado , totalApellido = totalesApellidos(apellido)
        return  f'Hay {totalApellidoSelecionado} personas con ese apellido de un total de {totalApellido}'
    except:
        f'Hay {0} personas con ese apellido de un total de {4560681}'
@app.callback(
    Output(component_id='frecuencia', component_property='children'),
    [Input(component_id='myInput', component_property='value')])
def totales_apellido(apellido):
    apellido = apellido.upper()
    try:
        mayorFre=mayorFrecuencia (apellido)
        return  f'Es mas frecuente en {mayorFre[0][0]},{mayorFre[0][1]},{mayorFre[0][2]},{mayorFre[0][3]},{mayorFre[0][4]}'
    except:  f'No se puede calcular donde es donde es mas frecuente este apellido'
        
@app.callback(
    Output(component_id='similar', component_property='children'),
    [Input(component_id='myInput', component_property='value')])
def totales_apellido(apellido):
    apellido = apellido.upper()
    listaPalabra=palabraSimilar(apellido)
    return  f'{", ".join(listaPalabra)}'

         




if __name__ == '__main__':
    app.run_server(debug=False)